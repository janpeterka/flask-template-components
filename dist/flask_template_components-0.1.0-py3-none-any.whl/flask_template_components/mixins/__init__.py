from .classful_linkable import ClassfulLinkableMixin

__all__ = ["ClassfulLinkableMixin"]
